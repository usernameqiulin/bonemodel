import React from 'react';
import ActionSheet from '../view/ActionSheet';

export default class ActionSheetPage extends Bone.Page {
  render() {
    return <ActionSheet />;
  }
}
