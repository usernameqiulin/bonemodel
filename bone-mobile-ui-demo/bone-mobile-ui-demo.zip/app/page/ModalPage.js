import React from 'react';
import Modal from '../view/Modal';

export default class ModalPage extends Bone.Page {
  render() {
    return <Modal />;
  }
}
