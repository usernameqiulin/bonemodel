import React from 'react';
import Radio from '../view/Radio';

export default class RadioPage extends Bone.Page {
  render() {
    return <Radio />;
  }
}
