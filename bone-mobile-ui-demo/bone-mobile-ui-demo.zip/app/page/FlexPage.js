import React from 'react';
import Flex from '../view/Flex';

export default class FlexPage extends Bone.Page {
  render() {
    return <Flex />;
  }
}
