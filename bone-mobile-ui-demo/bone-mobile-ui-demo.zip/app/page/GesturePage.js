import React from 'react';
import Gesture from '../view/Gesture';

export default class GesturePage extends Bone.Page {
  render() {
    return <Gesture />;
  }
}
