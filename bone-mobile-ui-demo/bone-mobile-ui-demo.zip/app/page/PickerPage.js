import React from 'react';
import Picker from '../view/Picker';

export default class PickerPage extends Bone.Page {
  render() {
    return <Picker />;
  }
}
