import React from 'react';
import Blank from '../view/Blank';

export default class BlankPage extends Bone.Page {
  render() {
    return <Blank />;
  }
}
