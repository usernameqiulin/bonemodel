import React from 'react';
import Checkbox from '../view/Checkbox';

export default class CheckboxPage extends Bone.Page {
  render() {
    return <Checkbox />;
  }
}
