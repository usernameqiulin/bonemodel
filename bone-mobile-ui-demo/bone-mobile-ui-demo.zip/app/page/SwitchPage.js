import React from 'react';
import Switch from '../view/Switch';

export default class SwitchPage extends Bone.Page {
  render() {
    return <Switch />;
  }
}
