import React from 'react';
import Toast from '../view/Toast';

export default class ToastPage extends Bone.Page {
  render() {
    return <Toast />;
  }
}
