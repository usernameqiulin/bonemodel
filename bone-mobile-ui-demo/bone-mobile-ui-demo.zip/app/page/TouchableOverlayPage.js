import React from 'react';
import TouchableOverlay from '../view/TouchableOverlay';

export default class TouchableOverlayPage extends Bone.Page {
  render() {
    return <TouchableOverlay />;
  }
}
