import React from 'react';
import Header from '../view/Header';

export default class HeaderPage extends Bone.Page {
  render() {
    return <Header />;
  }
}
