import React from 'react';
import NavBar from '../view/NavBar';

export default class NavBarPage extends Bone.Page {
  render() {
    return <NavBar />;
  }
}
