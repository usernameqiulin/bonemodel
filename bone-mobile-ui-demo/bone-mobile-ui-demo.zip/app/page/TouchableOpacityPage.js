import React from 'react';
import TouchableOpacity from '../view/TouchableOpacity';

export default class TouchableOpacityPage extends Bone.Page {
  render() {
    return <TouchableOpacity />;
  }
}
