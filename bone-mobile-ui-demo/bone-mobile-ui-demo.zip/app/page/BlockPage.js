import React from 'react';
import Block from '../view/Block';

export default class BlockPage extends Bone.Page {
  render() {
    return <Block />;
  }
}
