import React from 'react';
import Icon from '../view/Icon';

export default class IconPage extends Bone.Page {
  render() {
    return <Icon />;
  }
}
