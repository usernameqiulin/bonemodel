import React from 'react';
import Alert from '../view/Alert';

export default class AlertPage extends Bone.Page {
  render() {
    return <Alert />;
  }
}
