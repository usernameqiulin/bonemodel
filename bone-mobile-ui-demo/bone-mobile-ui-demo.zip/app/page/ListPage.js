import React from 'react';
import List from '../view/List';

export default class ListPage extends Bone.Page {
  render() {
    return <List />;
  }
}
